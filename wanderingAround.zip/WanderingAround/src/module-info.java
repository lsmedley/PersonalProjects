/**
 * 
 */
/**
 * @author csuser
 *
 */
module wanderingAround {
}