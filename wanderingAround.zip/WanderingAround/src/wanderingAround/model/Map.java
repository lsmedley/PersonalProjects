package wanderingAround.model;

import java.util.ArrayList;
import java.util.List;

public class Map {

	private List<Location> locals;
	private String name;
	private Location curLocation;
	
	public Map() {
		this.locals = new ArrayList<Location>();
		this.name = "";
		this.curLocation = new Location();
	}
	
	public Map(String name, List<Location> locals) {
		this.name = name;
		this.locals = locals;
		this.curLocation = this.locals.get(0);
	}
	
	
}
