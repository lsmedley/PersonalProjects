package wanderingAround.model;

public class Location {

	private String name;
	private String desc;
	private int squaresDown;
	private int squaresRight;
	
	public Location() {
		this.name = "";
		this.desc = "";
		this.squaresDown = 0;
		this.squaresRight = 0;
	}
	
	public Location(String name, String desc, int y, int x) {
		this.name = name;
		this.desc = desc;
		this.squaresDown = y;
		this.squaresRight = x;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getDesc() {
		return this.desc;
	}
	
	public int getSquaresDown() {
		return this.squaresDown;
	}
	
	public int getSquaresRight() {
		return this.squaresRight;
	}
	
	
}
