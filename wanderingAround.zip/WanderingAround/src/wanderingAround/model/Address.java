package wanderingAround.model;

public class Address {

	private int squaresDown;
	private int squaresRight;
	
	public Address() {
		this.squaresDown = 0;
		this.squaresRight = 0;
	}
	
}
