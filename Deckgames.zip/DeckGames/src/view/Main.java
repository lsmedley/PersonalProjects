package view;

import model.Deck;

public class Main {
	Deck deck = new Deck();
	
	for(int i = 0; i < deck.getSize(); i++) {
		
	}
}
