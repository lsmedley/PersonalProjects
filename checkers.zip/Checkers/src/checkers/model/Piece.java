package checkers.model;

public class Piece {

	private int squaresRight;
	private int squaresDown;
	private boolean color;
	
	public Piece() {
		this.squaresRight = 0;
		this.squaresDown = 0;
		this.color = false;
	}
	
	public Piece(int x, int y, boolean color) {
		this.squaresRight = x;
		this.squaresDown = y;
		this.color = color;
	}
	
	public int getX() {
		return this.squaresRight;
	}
	
	public int getY() {
		return this.squaresDown;
	}
	
	public boolean getColor() {
		return this.color;
	}
	
	public void setX(int x) {
		this.squaresRight = x; 
	}
	
	public void move(boolean dir) {
		if(dir) {
			this.squaresRight++;
			if(this.color) {
				this.squaresDown++;
			}
			else {
				this.squaresDown--;
			}
		}
		else {
			this.squaresRight--;
			if(this.color) {
				this.squaresDown++;
			}
			else {
				this.squaresDown--;
			}
		}
	}
	
	public void jump(boolean dir) {
		if(dir) {
			this.squaresRight += 2;
			if(this.color) {
				this.squaresDown += 2;
			}
			else {
				this.squaresDown -= 2;
			}
		}
		else {
			this.squaresRight -= 2;
			if(this.color) {
				this.squaresDown += 2;
			}
			else {
				this.squaresDown -= 2;
			}
		}
	}
}
