package checkers.model;

public class King extends Piece {

	public King() {
		super();
	}
	
	public King(int x, int y, boolean color) {
		super(x, y, color);
	}
	
	public void move(boolean x, boolean y) {
		if(x) {
			this.getX()++;
			if(y) {
				this.squaresDown++;
			}
			else {
				this.squaresDown--;
			}
		}
		else {
			this.getX()--;
			if(y) {
				this.squaresDown++;
			}
			else {
				this.squaresDown--;
			}
		}
	}
	
	public void jump(boolean x, boolean y) {
		if(x) {
			this.getX() += 2;
			if(y) {
				this.squaresDown += 2;
			}
			else {
				this.squaresDown -= 2;
			}
		}
		else {
			this.getX() -= 2;
			if(y) {
				this.squaresDown += 2;
			}
			else {
				this.squaresDown -= 2;
			}
		}
	}
	
	
}
