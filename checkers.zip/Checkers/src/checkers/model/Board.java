package checkers.model;

public class Board {

	
}
