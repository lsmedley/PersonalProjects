package view;

import java.util.Scanner;

import greed.model.Greed;
import model.Deck;

public class Main {
	public static void main(String[] args) {
		Deck deck = new Deck();
		Scanner kb = new Scanner(System.in);
		
		/*for(int i = 0; i < deck.getSize(); i++) {
			System.out.println(deck.getCard(i).toString());
		}
		
		System.out.println();
		deck.shuffle();
		
		for(int i = 0; i < deck.getSize(); i++) {
			System.out.println(deck.getCard(i).toString());
		}*/
		
		Greed game = new Greed();
		
		System.out.println("Greed: Get all the cards of one suit to win");
		
		while(!game.hasWon()) {
			game.drawCard();
			System.out.println(game.handToString());
			System.out.println("Which card will you discard? (Give the card's #)");
			
		}
	}
}
