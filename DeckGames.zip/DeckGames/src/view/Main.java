package view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import greed.model.Greed;
import model.Deck;
import model.Card;

public class Main {
	public static void main(String[] args) {
		Deck deck = new Deck();
		Scanner kb = new Scanner(System.in);
		
		/*for(int i = 0; i < deck.getSize(); i++) {
			System.out.println(deck.getCard(i).toString());
		}
		
		System.out.println();
		deck.shuffle();
		
		for(int i = 0; i < deck.getSize(); i++) {
			System.out.println(deck.getCard(i).toString());
		}*/
		
		Greed game = new Greed();
		List<Card> discard = new ArrayList<Card>();
		int turnCount = 0;
		
		System.out.println("Greed: Get all the cards of one suit to win");
		
		while(!game.hasWon()) {
			if(game.getDeck().getSize() > 0) {
				game.drawCard();
			} else {
				game.getDeck().setCards(discard);
				game.getDeck().shuffle();
				game.drawCard();
			}
			System.out.println("Your hand:");
			System.out.println(game.handToString());
			System.out.println("Which card will you discard? (Give the card's #)");
			int dis = kb.nextInt();
			Card play = game.playCard(dis);
			discard.add(play);
			turnCount++;
		}
		System.out.println("Congratulations! You won! And it only took " + turnCount + " turns!");
	}
}
