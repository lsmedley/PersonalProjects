package hunting.model;

import model.Hand;
import model.Suit;

import java.util.ArrayList;
import java.util.List;

import model.Card;

public class ComputerPlayer {
	private Hand hand;
	
	public ComputerPlayer() {
		this.hand = new Hand();
	}
	
	public ComputerPlayer(List<Card> hand) {
		this.hand = new Hand(hand);
	}
	
	public void addCard(Card c) {
		this.hand.addCard(c);
	}
	
	public Card getCard(Card c) {
		//return c if is in hand, otherwise return null
		return null;
	}
	
	private List<Card> findMatch() {
		List<Card> match = new ArrayList<Card>();
		for(Card c : this.hand.getCards()) {
			for(int i = 0; i < this.hand.getSize(); i++) {
				if(!c.equals(this.hand.getCard(i))) {
					if(c.getSuit().equals(this.hand.getCard(i).getSuit())) {
						match.add(c);
						match.add(this.hand.getCard(i));
					}
				}
			}
		}
		return match;
	}
	
	public String askCard() {
		String request = "Do you have a ";
		int rank = this.hand.getCard(0).getRank();
		Suit suit = this.hand.getCard(0).getSuit();
		
		if(rank > 7) {
			switch(rank) {
			case 8:
				request += "hawk ";
				break;
			case 9:
				request += "cat ";
				break;
			case 10:
				request += "prince ";
				break;
			case 11:
				request += "hunter ";
				break;
			case 12:
				request += "warrior ";
				break;
			case 13:
				request += "mother ";
				break;
			case 14:
				request += "queen ";
				break;
			}
		}
		else {
			request += rank + " ";
		}
		
		request += "of " + suit + "s?";
		
		return request;
	}
	
	public List<Card> playMatch() {
		List<Card> match = this.findMatch();
		
		for(Card c : match) {
			this.hand.playCard(c);
		}
		
		return match;
	}
	
	public boolean hasWon() {
		return this.hand.getCards().isEmpty();
	}
}
