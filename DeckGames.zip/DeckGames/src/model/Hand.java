package model;

import java.util.ArrayList;
import java.util.List;

public class Hand {

	private List<Card> cards;
	
	public Hand() {
		this.cards = new ArrayList<Card>();
	}
	
	public Hand(List<Card> cs) {
		this.cards = cs;
	}
	
	public Card getCard(int i) {
		return this.cards.get(i);
	}
	
	public int getSize() {
		return this.cards.size();
	}
	
	public void addCard(Card c) {
		this.cards.add(c);
	}
	
	public void playCard(Card c) {
		this.cards.remove(c);
	}
	
	public String toString() {
		String str = "";
		for(int i = 0; i < this.cards.size(); i++) {
			str += this.cards.get(i).toString();
			str += "; ";
		}
		
		return str;
	}
}
