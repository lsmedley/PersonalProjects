package model;

public enum Rank {
	HAWK, CAT, NIM, HUNTER, WARRIOR, MOTHER, QUEEN;
}
