package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Deck {
	private List<Card> cards;
	private Random rand;
	
	public Deck() {
		this.cards = new ArrayList<Card>();
		this.rand = new Random();
		
		this.fillDeck();
	}

	public int getSize() {
		return this.cards.size();
	}
	
	private void fillDeck() {
		Suit cur = Suit.FEATHER;
		for(int i = 1; i <= 14; i++) {
			this.cards.add(new Card(cur, i));
		}
		
		cur = Suit.NEEDLE;
		for(int i = 1; i <= 14; i++) {
			this.cards.add(new Card(cur, i));
		}
		
		cur = Suit.KNIFE;
		for(int i = 1; i <= 14; i++) {
			this.cards.add(new Card(cur, i));
		}
		
		cur = Suit.EYE;
		for(int i = 1; i <= 14; i++) {
			this.cards.add(new Card(cur, i));
		}
	}
	
	public void shuffle() {
		int index = this.rand.nextInt(this.cards.size());
		Card cur = this.cards.get(index);
		ArrayList<Card> shuffled = new ArrayList<Card>();
		
		shuffled.add(cur);
		this.cards.remove(index);
		
		while(!this.cards.isEmpty()) {
			index = this.rand.nextInt(this.cards.size());
			cur = this.cards.get(index);
			
			shuffled.add(cur);
			this.cards.remove(index);
		}
		
		this.cards = shuffled;
	}

	public Card getCard(int i) {
		return this.cards.get(i);
	}
	
	public Card takeCard(int i) {
		Card c = this.cards.remove(i);
		return c;
	}
	
	public Card drawNext() {
		if(!this.cards.isEmpty()) {
			return this.cards.remove(0);
		}
		return null;
	}
	
	public void setCards(List<Card> cs) {
		this.cards = cs;
	}
}
