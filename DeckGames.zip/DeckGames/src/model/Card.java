package model;

public class Card {
	
	private Suit suit;
	private int rank;
	
	public Card(Suit s, int r) {
		this.suit = s;
		this.rank = r;
	}
	
	public Suit getSuit() {
		return this.suit;
	}
	
	public int getRank() {
		return this.rank;
	}
	
	public String toString() {
		return this.suit + ", " + this.rank;
	}
}
