package model;

public enum Suit {
	FEATHER, NEEDLE, KNIFE, EYE;
}
