package greed.model;

import model.Card;
import model.Deck;
import model.Hand;
import model.Suit;

public class Greed {

	private Deck deck;
	private Hand hand;
	
	 public Greed() {
		 this.deck = new Deck();
		 this.hand = new Hand();
		 
		 this.deck.shuffle();
		 for(int i = 0; i < 14; i++) {
			 this.hand.addCard(this.deck.drawNext());
			 //System.out.println(this.deck.getCard(0));
		 }
	 }
	 
	 public String handToString() {
		 return this.hand.toString();
	 }
	 
	 public void drawCard() {
		 this.hand.addCard(this.deck.drawNext());
	 }
	 
	 public void playCard(Card c) {
		 this.hand.playCard(c);
	 }
	 
	 public boolean hasWon() {
		 Suit s = this.hand.getCard(0).getSuit();
		 
		 for(int i = 0; i < this.hand.getSize(); i++) {
			 if(this.hand.getCard(i).getSuit() != s) {
				 return false;
			 }
		 }
		 
		 return true;
	 }
}
