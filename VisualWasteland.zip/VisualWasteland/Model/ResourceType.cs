﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisualWasteland.Model
{
    public enum ResourceType
    {
        Wood = 0,
        Food = 1,
        Stone = 2,
        Sheep = 3,
        Baskets = 4,
        Axes = 5,
        Wolves =6
    }
}
