﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisualWasteland.Model
{
    class Town
    {
        /// <summary>
        /// Gets or sets the fire.
        /// </summary>
        /// <value>
        /// The fire.
        /// </value>
        private Fire fire { get; set; }
        /// <summary>
        /// Gets or sets the Resources.
        /// </summary>
        /// <value>
        /// The Resources.
        /// </value>
        public IList<Resource> Resources { get; private set; }

        private int population { get; set; }

        private Random rand;

        /// <summary>
        /// Initializes a new instance of the <see cref="Town"/> class.
        /// </summary>
        public Town()
        {
            this.fire = new Fire();
            this.Resources = new List<Resource>
            {
                new Resource(ResourceType.Wood, 10), new Resource(ResourceType.Food, 5)
            };
            this.population = 1;
            this.rand = new Random();
        }

        /// <summary>
        /// Determines whether [is fire lit].
        /// </summary>
        /// <returns>
        ///   <c>true</c> if [is fire lit]; otherwise, <c>false</c>.
        /// </returns>
        public Boolean IsFireLit()
        {
            return this.fire.IsLit;
        }

        /// <summary>
        /// Lights the fire.
        /// </summary>
        public void LightFire()
        {
            this.GetResourceByType(ResourceType.Wood).consume(5);
            this.fire.Light();
        }

        /// <summary>
        /// Eats this instance.
        /// </summary>
        public void Eat()
        {
            this.GetResourceByType(ResourceType.Food).consume(this.population);
        }

        /// <summary>
        /// Burns the fire.
        /// </summary>
        public void BurnFire()
        {
            this.fire.Dwindle();
        }

        /// <summary>
        /// Stokes the fire.
        /// </summary>
        public void StokeFire()
        {
            this.GetResourceByType(ResourceType.Wood).consume(1);
            this.fire.Stoke();
        }

        /// <summary>
        /// Gathers an amount of food based on population and # of baskets.
        /// TODO: implement baskets
        /// </summary>
        public int GatherFood()
        {
            int foodGathered = 0;

            if (this.GetResourceByType(ResourceType.Baskets) != null)
            {
                if (this.GetResourceByType(ResourceType.Baskets).Quantity >= this.population)
                {
                    foodGathered = rand.Next(1, 11) * this.population;
                }
                else
                {
                    foodGathered = rand.Next(1, 11) * this.GetResourceByType(ResourceType.Baskets).Quantity;
                    foodGathered += rand.Next(1, 6) * (this.population - this.GetResourceByType(ResourceType.Baskets).Quantity);
                }
            }
            else
            {
                foodGathered = rand.Next(1, 6) * this.population;
            }

            this.GetResourceByType(ResourceType.Food).gather(foodGathered);
            return foodGathered;
        }

        /// <summary>
        /// Gathers an amount of wood based on population and # of axes.
        /// TODO: implement axes
        /// </summary>
        public int GatherWood()
        {
            int woodGathered = 0;

            if (this.GetResourceByType(ResourceType.Axes) != null)
            {
                if (this.GetResourceByType(ResourceType.Axes).Quantity >= this.population)
                {
                    woodGathered = rand.Next(1, 11) * this.population;
                }
                else
                {
                    woodGathered = rand.Next(1, 11) * this.GetResourceByType(ResourceType.Axes).Quantity;
                    woodGathered += rand.Next(1, 6) * (this.population - this.GetResourceByType(ResourceType.Axes).Quantity);
                }
            }
            else
            {
                woodGathered = rand.Next(1, 6) * this.population;
            }

            this.GetResourceByType(ResourceType.Wood).gather(woodGathered);

            return woodGathered;
        }

        /// <summary>
        /// Gets the type of the resource by.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns></returns>
        public Resource GetResourceByType(ResourceType type)
        {
            foreach (Resource res in this.Resources)
            {
                if (res.Type.Equals(type))
                {
                    return res;
                }
            }

            return null;
        }


    }
}
