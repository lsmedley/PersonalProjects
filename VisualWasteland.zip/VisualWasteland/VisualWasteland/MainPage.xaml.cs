﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using VisualWasteland.Controller;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace VisualWasteland
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {

        private GameManager gameManager;
        public MainPage()
        {
            this.gameManager = new GameManager();

            this.InitializeComponent();
            this.UpdateStatusOutput();
            this.UpdateResourcesOutput();
        }

        private void UpdateStatusOutput()
        {
            if (!this.gameManager.IsFireLit())
            {
                this.statusOutput.Text = "The fire is out. You are cold.";
            }
            else
            {
                this.statusOutput.Text = "The fire is burning. You are warm.";
            }
        }

        private void UpdateResourcesOutput()
        {
            this.resourcesOutput.Text = "Resources:" + Environment.NewLine + this.gameManager.getResources();
        }

        private void LightFireButton_Click(object sender, RoutedEventArgs e)
        {
            this.gameManager.LightFire();
            this.gameManager.MoveToNextDay();

            this.UpdateStatusOutput();
            this.UpdateResourcesOutput();
        }

        private void StokeFireButton_Click(object sender, RoutedEventArgs e)
        {
            this.gameManager.StokeFire();
            this.gameManager.MoveToNextDay();

            this.UpdateStatusOutput();
            this.UpdateResourcesOutput();
        }

        private void GatherWoodButton_Click(object sender, RoutedEventArgs e)
        {
            int wood = this.gameManager.GatherWood();
            this.gameManager.MoveToNextDay();

            this.UpdateStatusOutput();
            this.UpdateResourcesOutput();
            this.statusOutput.Text += "You gathered " + wood + " wood.";
        }

        private void GatherFoodButton_Click(object sender, RoutedEventArgs e)
        {
            int food = this.gameManager.GatherFood();
            this.gameManager.MoveToNextDay();

            this.UpdateStatusOutput();
            this.UpdateResourcesOutput();
            this.statusOutput.Text += "You gathered " + food + " food.";
        }
    }
}
