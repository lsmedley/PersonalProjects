﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisualWasteland.Model
{
    public class Resource
    {
        public string Type { get; }
        public int Quantity { get; private set;}

        public Resource(string type, int quantity)
        {
            this.Type = type;
            this.Quantity = quantity;
        }

        public void consume(int amount)
        {
            this.Quantity -= amount;
        }

        public void gather(int amount)
        {
            this.Quantity += amount;
        }
    }
}
