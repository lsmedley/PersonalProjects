﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisualWasteland.Model
{
    public class Resource
    {
        /// <summary>Gets the type.</summary>
        /// <value>The type.</value>
        public string Type { get; }
        /// <summary>
        /// Gets the quantity.
        /// </summary>
        /// <value>
        /// The quantity.
        /// </value>
        public int Quantity { get; private set;}

        /// <summary>
        /// Initializes a new instance of the <see cref="Resource"/> class.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="quantity">The quantity.</param>
        public Resource(string type, int quantity)
        {
            this.Type = type;
            this.Quantity = quantity;
        }

        /// <summary>
        /// Consumes the specified amount.
        /// </summary>
        /// <param name="amount">The amount.</param>
        public void consume(int amount)
        {
            this.Quantity -= amount;
        }

        /// <summary>
        /// Gathers the specified amount.
        /// </summary>
        /// <param name="amount">The amount.</param>
        public void gather(int amount)
        {
            this.Quantity += amount;
        }
    }
}
