﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisualWasteland.Model
{
    class Town
    {
        private Fire fire { get; set; }
        private IList<Resource> resources { get; set; }

        public Town()
        {
            this.fire = new Fire();
            this.resources = new List<Resource>
            {
                new Resource("Wood", 10), new Resource("Food", 5)
            };
        }
    }
}
