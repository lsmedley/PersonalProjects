﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisualWasteland.Model
{
    class Fire
    {
        public int Strength { get; private set; }

        public Boolean isLit { get; private set; }

        private Random rand;

        public Fire()
        {
            this.Strength = 0;
            this.isLit = false;
            this.rand = new Random();
        }

        public void Stoke()
        {
            this.Strength += rand.Next(1, 8);
        }

        public void Dwindle()
        {
            this.Strength--;
        }
    }
}
