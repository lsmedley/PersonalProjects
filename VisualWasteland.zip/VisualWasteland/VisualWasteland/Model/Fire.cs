﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisualWasteland.Model
{
    class Fire
    {
        /// <summary>
        /// Gets the strength.
        /// </summary>
        /// <value>
        /// The strength.
        /// </value>
        public int Strength { get; private set; }

        /// <summary>
        /// Gets a value indicating whether this instance is lit.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is lit; otherwise, <c>false</c>.
        /// </value>
        public Boolean isLit { get; private set; }

        private Random rand;

        /// <summary>
        /// Initializes a new instance of the <see cref="Fire"/> class.
        /// </summary>
        public Fire()
        {
            this.Strength = 0;
            this.isLit = false;
            this.rand = new Random();
        }

        /// <summary>
        /// Stokes this instance.
        /// </summary>
        public void Stoke()
        {
            this.Strength += rand.Next(1, 8);
        }

        /// <summary>
        /// Dwindles this instance.
        /// </summary>
        public void Dwindle()
        {
            this.Strength--;
        }
    }
}
