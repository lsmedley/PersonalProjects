﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VisualWasteland.Model;

namespace VisualWasteland.Controller
{
    class GameManager
    {
        private Town town;

        public Boolean HasLost { get; private set; }

        public int CurrentDay { get; private set; }

        public string CauseOfDeath { get; private set; }

        public GameManager()
        {
            this.town = new Town();
            this.HasLost = false;
            this.CurrentDay = 1;
            this.CauseOfDeath = "";
        }

        /// <summary>Gets the resources.</summary>
        /// <returns>A string of the resources.</returns>
        public string getResources()
        {
            string rString = "";
            foreach (Resource r in this.town.Resources)
            {
                rString += r.toString() + Environment.NewLine;
            }

            return rString;
        }

        /// <summary>
        /// Moves to next day.
        /// </summary>
        public void MoveToNextDay()
        {
            if(!this.town.IsFireLit())
            {
                this.HasLost = true;
                this.CauseOfDeath = "Exposure";
            }
            this.CurrentDay++;
            this.town.Eat();
            this.town.BurnFire();
            if (this.town.GetResourceByType("Food").Quantity <= 0)
            {
                this.HasLost = true;
                this.CauseOfDeath = "Starvation";
            }
        }

        public void LightFire()
        {
            this.town.LightFire();
        }

        public void StokeFire()
        {
            this.town.StokeFire();
        }

        public int GatherWood()
        {
            return this.town.GatherWood();
        }

        public int GatherFood()
        {
            return this.town.GatherFood();
        }

        public bool IsFireLit()
        {
            return this.town.IsFireLit();
        }
    }
}
