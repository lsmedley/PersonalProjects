package wanderingAround.model;

public class Location {

	private String name;
	private String desc;
	private Address add;
	
	public Location() 
	{
		this.name = "";
		this.desc = "";
		this.add = new Address();
	}
	
	public Location(String name, String desc, int y, int x) 
	{
		this.name = name;
		this.desc = desc;
		this.add = new Address(y, x);
	}
	
	public String getName() 
	{
		return this.name;
	}
	
	public String getDesc() 
	{
		return this.desc;
	}
	
	public Address getAddress() 
	{
		return this.add;
	}
	
	
}
