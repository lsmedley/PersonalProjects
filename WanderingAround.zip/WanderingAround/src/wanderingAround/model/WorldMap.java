package wanderingAround.model;

import java.util.ArrayList;
import java.util.List;

public class WorldMap {

	private List<Location> locals;
	private String name;
	private Location curLocation;
	
	public WorldMap() {
		this.locals = new ArrayList<Location>();
		this.name = "";
		this.curLocation = new Location();
	}
	
	public WorldMap(String name, List<Location> locals) {
		this.name = name;
		this.locals = locals;
		this.curLocation = this.locals.get(0);
	}
	
	public WorldMap(String name, List<Location> locals, int startLocal) {
		this.name = name;
		this.locals = locals;
		this.curLocation = this.locals.get(startLocal);
	}
	
	public List<Location> getLocals() {
		return this.locals;
	}
	
	public Location getCurLocal() {
		return this.curLocation;
	}
	
	public Location getLocal(int rank) {
		return this.locals.get(rank);
	}
	
	public Location getLocal(String name) {
		for(Location l : this.locals) {
			if(l.getName().equals(name)) {
				return l;
			}
		}
		return null;
	}
	
	public List<Location> getNeighbors() {
		ArrayList<Location> neighs = new ArrayList<Location>();
		
		for(Location l : this.locals) {
			if(l.getAddress().getSquaresDown() - this.curLocation.getAddress().getSquaresDown() == 1
					|| l.getAddress().getSquaresDown() - this.curLocation.getAddress().getSquaresDown() == -1) {
				neighs.add(l);
			}
			else if(l.getAddress().getSquaresRight() - this.curLocation.getAddress().getSquaresRight() == 1
					|| l.getAddress().getSquaresRight() - this.curLocation.getAddress().getSquaresRight() == -1) {
				neighs.add(l);
			}
			
		}
		
		return neighs;
	}
	
	public boolean move(int y, int x) {
		for(Location loc : this.locals) {
			if(this.curLocation.getAddress().getSquaresDown() + y == loc.getAddress().getSquaresDown()
					&& this.curLocation.getAddress().getSquaresRight() + x == loc.getAddress().getSquaresRight()) {
				this.curLocation = loc;
				return true;
			}
		}
		return false;
	}
	
	public Address parseMove(String move) {
		if(move.length() < 1 || move.length() > 2) {
			throw new IllegalArgumentException("Invalid command.");
		}
		
		Address moveAdd = null;
		
		if(move.toUpperCase().equals("N")) {
			moveAdd = new Address(-1, 0);
		}
		else if(move.toUpperCase().equals("S")) {
			moveAdd = new Address(1, 0);
		}
		else if(move.toUpperCase().equals("E")) {
			moveAdd = new Address(0, 1);
		}
		else if(move.toUpperCase().equals("W")) {
			moveAdd = new Address(0, 1);
		}
		else if(move.toUpperCase().equals("NE")) {
			moveAdd = new Address(-1, 1);
		}
		else if(move.toUpperCase().equals("NW")) {
			moveAdd = new Address(-1, -1);
		}
		else if(move.toUpperCase().equals("SE")) {
			moveAdd = new Address(1, 1);
		}
		else if(move.toUpperCase().equals("SW")) {
			moveAdd = new Address(1, -1);
		}
		
		return moveAdd;
	}
	
	public void goTo(int rank) {
		this.curLocation = this.locals.get(rank);
	}
}
