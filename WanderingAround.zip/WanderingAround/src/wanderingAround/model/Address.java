package wanderingAround.model;

public class Address {

	private int squaresDown;
	private int squaresRight;
	
	public Address() {
		this.squaresDown = 0;
		this.squaresRight = 0;
	}
	
	public Address(int down, int right) {
		this.squaresDown = down;
		this.squaresRight = right;
	}
	
	public int getSquaresDown() {
		return this.squaresDown;
	}
	
	public int getSquaresRight() {
		return this.squaresRight;
	}
}
