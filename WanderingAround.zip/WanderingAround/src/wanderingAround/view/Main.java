package wanderingAround.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import wanderingAround.model.Location;
import wanderingAround.model.WorldMap;

public class Main {

	public static void main(String[] args) {
		List<Location> locals = new ArrayList<Location>();
		
		//Locations:
		Location l1 = new Location("Northwest Corner", "You stand behind and slightly west of the shed.", 0, 0);
		Location l2 = new Location("Shed Back", "1", 0, 1);
		Location l3 = new Location("Northeast Corner", "2", 0, 2);
		Location l4 = new Location("West Wall", "3", 1, 0);
		Location l5 = new Location("Shed", "4", 1, 1);
		Location l6 = new Location("East Wall", "5", 1, 2);
		Location l7 = new Location("Southwest Corner", "6", 2, 0);
		Location l8 = new Location("Shed Door", "7", 2, 1);
		Location l9 = new Location("Southeast Corner", "8", 2, 2);

		locals.add(l1);
		locals.add(l2);
		locals.add(l3);
		locals.add(l4);
		locals.add(l5);
		locals.add(l6);
		locals.add(l7);
		locals.add(l8);
		locals.add(l9);
		
		WorldMap shedWorld = new WorldMap("Shed World", locals, 4);
		
		boolean playing = true;
		
		while(playing == true) {
			System.out.println(shedWorld.getCurLocal().getName());
			System.out.println("Which way would you like to go?");
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			String dir = "";
			try {
				dir = in.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if(dir.toLowerCase().equals("stop")) {
				playing = false;
			}
			System.out.println(dir);
			//call parseMove + move w/ dir!
		}
	}
}
