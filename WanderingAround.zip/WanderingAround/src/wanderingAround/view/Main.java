package wanderingAround.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import wanderingAround.model.Address;
import wanderingAround.model.Location;
import wanderingAround.model.WorldMap;

public class Main {

	public static void main(String[] args) {
		List<Location> locals = new ArrayList<Location>();
		
		//Locations:
		Location l1 = new Location("Northwest Corner", "You stand behind and slightly west of the shed."
				+ "\nTo your north the world ends, west doesn't exist, to your south is the west side of the shed and to your east is the north wall of the shed.", 0, 0);
		Location l2 = new Location("Shed Back", "You stand directly behind the shed."
				+ "\nTo your north the world ends, to your west is the northwest corner of the shed, to your east is the northeast corner of the shed, and to your south is the shed.", 0, 1);
		Location l3 = new Location("Northeast Corner", "You stand behind and slightly east of the shed.", 0, 2);
		Location l4 = new Location("West Wall", "You stand to the west of the shed.", 1, 0);
		Location l5 = new Location("Shed", "You stand inside a small shed made of wood. It seems to have been falling apart for a long time.", 1, 1);
		Location l6 = new Location("East Wall", "You stand to the east of the shed", 1, 2);
		Location l7 = new Location("Southwest Corner", "You stand in front of and slightly west of the shed.", 2, 0);
		Location l8 = new Location("Shed Door", "You stand before the shed door. Half is stained from water damage and the other half is rotted away."
				+ "\nTo your north is the shed, east and west are the east and west corners of the shed, and to the south is a dirt path.", 2, 1);
		Location l9 = new Location("Southeast Corner", "You stand in front of and slightly east of the shed.", 2, 2);
		
		//path:
		Location p1 = new Location("Dirt Path 0", "You are on a dirt path."
				+ "\nTo your north is the door to the shed, east and west don't exist, and to your south the path continues.", 3, 1);
		Location p2 = new Location("Dirt Path 1", "You are on a dirt path."
				+ "\nTo your north the path continues towards the shed, east and west don't exist, and to your south the path continues.", 4, 1);
		Location p3 = new Location("Dirt Path 2", "You are on a dirt path."
				+ "\nTo your north the path continues towards the shed, south and west don't exist, and to your east the path continues.", 5, 1);
		Location p4 = new Location("Dirt Path 3", "You are on a dirt path."
				+ "\nTo your west the path continues towards the shed, south and north don't exist, and to your east the path continues.", 5, 2);
		Location p5 = new Location("Dirt Path 4", "You are on a dirt path."
				+ "\nTo your west the path continues towards the shed, north and east don't exist, and to your south the path continues.", 5, 3);
		Location p6 = new Location("Dirt Path 5", "You are on a dirt path."
				+ "\nTo your north the path continues towards the shed, east and west don't exist, and to your south you see a house.", 6, 3);
		
		//house
		Location h0 = new Location("House Front 1", "", 8, 2);
		Location h1 = new Location("House Front 2", "You stand in front of an old mansion. It looks like it's been long abandoned now, but it was probably pretty cool at one point." 
				+ "\nTo your north there's a dirt path, east and west are in front of the house, and to the south there is a porch.", 8, 3);
		Location h2 = new Location("House Front 3", "", 8, 4);
		Location h3 = new Location("West Porch", "", 9, 2);
		Location h4 = new Location("Mid Porch", "", 9, 3);
		Location h5 = new Location("East Porch", "", 9, 4);
		Location h6 = new Location("House Front Door", "", 10, 3);
		Location h7 = new Location("Servant's Bedroom 1", "", 11, 1);
		Location h8 = new Location("Coat Room", "", 11, 2);
		Location h9 = new Location("Front Hall", "", 11, 3);
		Location h10 = new Location("Nice Living Room", "", 11, 4);
		Location h11 = new Location("Nice Guest Bedroom", "", 11, 5);
		Location h12 = new Location("Patio 1", "", 11, 6);
		Location h13 = new Location("Bathroom", "", 12, 1);
		Location h14 = new Location("Diningroom", "", 12, 2);
		Location h15 = new Location("Mid Hall", "", 12, 3);
		Location h16 = new Location("Bad Living Room", "", 12, 4);
		Location h17 = new Location("Bad Guest Bedroom", "", 12, 5);
		Location h18 = new Location("Patio 2", "", 12, 6);
		Location h19 = new Location("Servant's Bedroom 2", "", 13, 1);
		Location h20 = new Location("Kitchen", "", 13, 2);
		Location h21 = new Location("Back Hall", "", 13, 3);
		Location h22 = new Location("Bedroom 1", "", 13, 4);
		Location h23 = new Location("Bedroom 2", "", 13, 5);
		Location h24 = new Location("Patio 3", "", 13, 6);
		Location h25 = new Location("Kitchen Door", "", 14, 2);
		Location h26 = new Location("Back Door", "", 14, 3);

		locals.add(l1);
		locals.add(l2);
		locals.add(l3);
		locals.add(l4);
		locals.add(l5);
		locals.add(l6);
		locals.add(l7);
		locals.add(l8);
		locals.add(l9);
		
		locals.add(p1);
		locals.add(p2);
		locals.add(p3);
		locals.add(p4);
		locals.add(p5);
		locals.add(p6);
		
		//Add house locals
		/*for(int i = 0; i < 27; i++) {
			
		}*/
		locals.add(h0);
		locals.add(h1);
		locals.add(h2);
		locals.add(h3);
		locals.add(h4);
		locals.add(h5);
		locals.add(h6);
		locals.add(h7);
		locals.add(h8);
		locals.add(h9);
		locals.add(h10);
		locals.add(h11);
		locals.add(h12);
		locals.add(h13);
		locals.add(h14);
		locals.add(h15);
		locals.add(h16);
		locals.add(h17);
		locals.add(h18);
		locals.add(h19);
		locals.add(h20);
		locals.add(h21);
		locals.add(h22);
		locals.add(h23);
		locals.add(h24);
		locals.add(h25);
		locals.add(h26);
		
		WorldMap shedWorld = new WorldMap("Shed World", locals, 4);
		
		boolean playing = true;
		
		while(playing == true) {
			System.out.println(shedWorld.getCurLocal().getName());
			System.out.println(shedWorld.getCurLocal().getDesc());
			System.out.println("Which way would you like to go?");
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			String dir = "";
			try {
				dir = in.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if(dir.toLowerCase().equals("stop")) {
				playing = false;
			}
			else {
				Address move = shedWorld.parseMove(dir);
				boolean result = shedWorld.move(move.getSquaresDown(), move.getSquaresRight());
				if(result == false) {
					System.out.println("There's nowhere to go that way! You stay where you are.");
				}
				else {
					System.out.println("You successfully move " + dir);
				}
			}
		}
	}
}
